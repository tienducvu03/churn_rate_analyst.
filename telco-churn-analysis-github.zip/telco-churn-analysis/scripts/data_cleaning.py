"""
Data Cleaning & Preprocessing Script
Telco Customer Churn Analysis

Author: Vũ Tiến Đức
Email: vutienduc.31032003@gmail.com
"""

import pandas as pd
import numpy as np
from typing import Tuple
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def load_data(filepath: str) -> pd.DataFrame:
    """Load the Telco Customer Churn dataset."""
    logger.info(f"Loading data from {filepath}")
    df = pd.read_csv(filepath)
    logger.info(f"Loaded {len(df):,} records with {len(df.columns)} columns")
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and preprocess the dataset."""
    logger.info("Starting data cleaning...")
    df_clean = df.copy()
    
    # Convert TotalCharges to numeric
    df_clean['TotalCharges'] = pd.to_numeric(df_clean['TotalCharges'], errors='coerce')
    
    # Handle missing values
    missing_total = df_clean['TotalCharges'].isnull().sum()
    if missing_total > 0:
        logger.info(f"Found {missing_total} missing values in TotalCharges")
        df_clean.loc[df_clean['tenure'] == 0, 'TotalCharges'] = 0
        df_clean['TotalCharges'].fillna(df_clean['TotalCharges'].median(), inplace=True)
    
    # Remove duplicates
    duplicates = df_clean.duplicated().sum()
    if duplicates > 0:
        logger.info(f"Removing {duplicates} duplicate rows")
        df_clean.drop_duplicates(inplace=True)
    
    logger.info(f"Data cleaning completed. Final shape: {df_clean.shape}")
    return df_clean


def create_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create additional features for analysis."""
    logger.info("Creating new features...")
    df_feat = df.copy()
    
    # Tenure buckets
    df_feat['tenure_bucket'] = pd.cut(
        df_feat['tenure'],
        bins=[0, 6, 12, 24, 48, 72],
        labels=['0-6 months', '7-12 months', '13-24 months', '25-48 months', '49-72 months']
    )
    
    # Average monthly spend
    df_feat['AvgMonthlySpend'] = df_feat['TotalCharges'] / (df_feat['tenure'] + 1)
    
    # Number of services
    service_cols = ['PhoneService', 'OnlineSecurity', 'OnlineBackup', 
                    'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies']
    
    def count_services(row):
        count = 0
        for col in service_cols:
            if col in row and row[col] not in ['No', 'No internet service']:
                count += 1
        return count
    
    df_feat['num_services'] = df_feat.apply(count_services, axis=1)
    
    # Binary churn
    df_feat['Churn_Binary'] = df_feat['Churn'].map({'Yes': 1, 'No': 0})
    
    logger.info(f"Feature engineering completed.")
    return df_feat


def encode_features(df: pd.DataFrame, target_col: str = 'Churn') -> Tuple[pd.DataFrame, pd.Series]:
    """Encode categorical features for modeling."""
    logger.info("Encoding features for modeling...")
    df_encoded = df.copy()
    
    # Drop non-feature columns
    cols_to_drop = ['customerID', 'Churn_Binary', 'tenure_bucket']
    df_encoded = df_encoded.drop(columns=[c for c in cols_to_drop if c in df_encoded.columns])
    
    # Separate target
    y = df_encoded[target_col].map({'Yes': 1, 'No': 0})
    X = df_encoded.drop(columns=[target_col])
    
    # Binary encoding
    binary_map = {'Yes': 1, 'No': 0, 'Male': 1, 'Female': 0}
    binary_cols = ['gender', 'Partner', 'Dependents', 'PhoneService', 'PaperlessBilling']
    for col in binary_cols:
        if col in X.columns:
            X[col] = X[col].map(binary_map)
    
    # One-hot encoding
    cat_cols = X.select_dtypes(include=['object']).columns.tolist()
    X = pd.get_dummies(X, columns=cat_cols, drop_first=True)
    
    logger.info(f"Encoding completed. Features: {X.shape[1]}")
    return X, y


def calculate_churn_rate(df: pd.DataFrame, groupby_col: str) -> pd.DataFrame:
    """Calculate churn rate by a specific column."""
    result = df.groupby(groupby_col).agg(
        total_customers=('Churn', 'count'),
        churned=('Churn', lambda x: (x == 'Yes').sum()),
        churn_rate=('Churn', lambda x: (x == 'Yes').mean() * 100)
    ).round(2)
    return result.sort_values('churn_rate', ascending=False)


def generate_summary_stats(df: pd.DataFrame) -> dict:
    """Generate summary statistics for the dataset."""
    churn_counts = df['Churn'].value_counts()
    return {
        'total_customers': len(df),
        'churned_customers': churn_counts.get('Yes', 0),
        'churn_rate': (churn_counts.get('Yes', 0) / len(df) * 100),
        'avg_tenure': df['tenure'].mean(),
        'avg_monthly_charges': df['MonthlyCharges'].mean(),
        'revenue_at_risk': df[df['Churn'] == 'Yes']['MonthlyCharges'].sum()
    }


if __name__ == "__main__":
    print("="*60)
    print("TELCO CUSTOMER CHURN - DATA PROCESSING")
    print("Author: Vũ Tiến Đức")
    print("="*60)
    
    df = load_data('../data/cleaned_telco_customer_churn.csv')
    df_clean = clean_data(df)
    df_features = create_features(df_clean)
    
    stats = generate_summary_stats(df_features)
    
    print(f"\n📊 DATASET SUMMARY:")
    print(f"   Total Customers: {stats['total_customers']:,}")
    print(f"   Churn Rate: {stats['churn_rate']:.1f}%")
    print(f"   Revenue at Risk: ${stats['revenue_at_risk']:,.2f}/month")
    
    print("\n✅ Data processing completed!")
