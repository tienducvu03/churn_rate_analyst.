# 📊 Executive Summary: Telco Customer Churn Analysis

**Prepared by:** Vũ Tiến Đức  
**Date:** February 2025  
**Contact:** vutienduc.31032003@gmail.com | 0367108536

---

## 🎯 Objective

Analyze customer churn patterns to identify at-risk customers and recommend retention strategies to reduce churn rate by 25%.

---

## 📈 Key Findings

### Current State
| Metric | Value |
|--------|-------|
| Total Customers | 7,043 |
| Current Churn Rate | 26.5% |
| Monthly Revenue at Risk | $139,130 |
| Annual Revenue at Risk | $1,669,560 |

### Top Churn Drivers

| Rank | Factor | Churn Rate | vs. Average |
|------|--------|------------|-------------|
| 1 | Month-to-month Contract | 42.7% | +16.2% |
| 2 | Fiber Optic (No Support) | 41.9% | +15.4% |
| 3 | Electronic Check Payment | 45.3% | +18.8% |
| 4 | Tenure < 6 months | 47.4% | +20.9% |
| 5 | No Tech Support | 41.6% | +15.1% |

---

## 💡 Recommendations

### 1. New Customer Onboarding (Priority: HIGH)
- **Target:** Customers with tenure < 6 months
- **Action:** 90-day intensive support program
- **Expected Impact:** -15% churn in segment
- **Investment:** $50,000/year
- **ROI:** 300%+

### 2. Contract Migration Program (Priority: HIGH)
- **Target:** Month-to-month customers
- **Action:** 20% discount for 1-year commitment
- **Expected Impact:** -20% churn, +5% ARPU
- **Investment:** $100,000/year (discounts)
- **ROI:** 250%+

### 3. Service Bundle Promotion (Priority: MEDIUM)
- **Target:** Fiber optic customers without add-ons
- **Action:** Bundle Tech Support + Security at 30% off
- **Expected Impact:** -12% churn, +$15 ARPU
- **Investment:** $75,000/year
- **ROI:** 200%+

### 4. Payment Method Optimization (Priority: MEDIUM)
- **Target:** Electronic check users
- **Action:** $10 credit for auto-pay enrollment
- **Expected Impact:** -10% churn
- **Investment:** $25,000/year
- **ROI:** 400%+

---

## 📊 Predictive Model Performance

| Model | Accuracy | Precision | Recall | ROC AUC |
|-------|----------|-----------|--------|---------|
| Random Forest | 79.5% | 65.2% | 52.8% | 84.1% |
| Gradient Boosting | 80.1% | 66.4% | 51.2% | 84.5% |
| Logistic Regression | 78.2% | 62.1% | 54.3% | 82.3% |

**Recommendation:** Use Random Forest for balanced precision/recall.

---

## 💰 Financial Impact Summary

| Scenario | Customers Saved | Revenue Retained/Year |
|----------|-----------------|----------------------|
| Conservative (15% improvement) | 280 | $500,000+ |
| Moderate (25% improvement) | 467 | $835,000+ |
| Aggressive (35% improvement) | 654 | $1,170,000+ |

---

## 🚀 Next Steps

1. **Week 1-2:** Implement high-risk customer alerts
2. **Week 3-4:** Launch contract migration campaign
3. **Month 2:** Roll out onboarding program
4. **Month 3:** Evaluate and optimize

---

**Questions?** Contact: vutienduc.31032003@gmail.com
