# 📊 Telco Customer Churn Analysis

[![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)](https://www.python.org/)
[![SQL](https://img.shields.io/badge/SQL-PostgreSQL-336791.svg)](https://www.postgresql.org/)
[![PowerPoint](https://img.shields.io/badge/Presentation-PPTX-B7472A.svg)](./presentation/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> **Data Analytics Portfolio Project**  
> Phân tích và dự đoán khách hàng rời bỏ dịch vụ viễn thông

**Author:** Vũ Tiến Đức  
**Email:** vutienduc.31032003@gmail.com  
**Phone:** 0367108536

---

## 🎯 Project Overview

Dự án phân tích dữ liệu khách hàng của công ty viễn thông nhằm:
- Xác định các yếu tố dẫn đến việc khách hàng rời bỏ dịch vụ (churn)
- Phân khúc khách hàng theo mức độ rủi ro
- Xây dựng model dự đoán churn
- Đề xuất chiến lược giữ chân khách hàng

### 💼 Business Impact
| Metric | Value |
|--------|-------|
| Churn Rate hiện tại | 26.5% |
| Revenue at Risk | $139K/tháng |
| Model ROC-AUC | 84% |
| Potential Savings | $1.67M/năm |

---

## 📁 Project Structure

```
telco-churn-analysis/
│
├── 📁 data/
│   └── cleaned_telco_customer_churn.csv   # Dataset (7,043 customers)
│
├── 📁 notebooks/
│   ├── 01_exploratory_data_analysis.ipynb # EDA & Visualization
│   └── 02_predictive_modeling.ipynb       # ML Models
│
├── 📁 sql/
│   └── churn_analysis_queries.sql         # 30+ SQL queries
│
├── 📁 scripts/
│   └── data_cleaning.py                   # Python utilities
│
├── 📁 presentation/
│   └── Customer_Churn_Analysis.pptx       # Business presentation (15 slides)
│
├── 📁 reports/
│   └── executive_summary.md               # Executive summary
│
├── requirements.txt
├── .gitignore
└── README.md
```

---

## 🔑 Key Findings

### Top Churn Drivers

| Rank | Factor | Churn Rate | vs Average |
|------|--------|------------|------------|
| 1 | Month-to-month Contract | 42.7% | +16.2% |
| 2 | Tenure < 12 months | 47.7% | +21.2% |
| 3 | Electronic Check Payment | 45.3% | +18.8% |
| 4 | Fiber Optic (No Support) | 41.9% | +15.4% |
| 5 | No Tech Support | 41.6% | +15.1% |

### High-Risk Segments

| Segment | Description | Churn Rate |
|---------|-------------|------------|
| 🔴 Highest | New + Month-to-month + E-check | ~60% |
| 🟠 High | Fiber Optic + No add-ons | ~50% |
| 🟡 Medium | Senior Citizens | 41.7% |
| 🟢 Low | Two-year + Auto-pay + Support | <5% |

---

## 💻 Technical Skills Demonstrated

| Category | Skills |
|----------|--------|
| **Programming** | Python, SQL |
| **Libraries** | Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn |
| **Analysis** | EDA, Statistical Testing, Feature Engineering |
| **ML Models** | Logistic Regression, Random Forest, Gradient Boosting |
| **Visualization** | Charts, Dashboards, PowerPoint |
| **Tools** | Jupyter, Git/GitHub |

---

## 🚀 Quick Start

### Prerequisites
- Python 3.9+
- Jupyter Notebook

### Installation

```bash
# Clone repository
git clone https://github.com/vutienduc/telco-churn-analysis.git
cd telco-churn-analysis

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

# Install dependencies
pip install -r requirements.txt

# Launch Jupyter
jupyter notebook
```

### Run Analysis
1. Open `notebooks/01_exploratory_data_analysis.ipynb`
2. Run all cells
3. Continue with `02_predictive_modeling.ipynb`

---

## 📊 Model Performance

| Model | Accuracy | Precision | Recall | ROC-AUC |
|-------|----------|-----------|--------|---------|
| **Logistic Regression** ⭐ | 79.9% | 64.3% | 54.8% | **84.0%** |
| Random Forest | 79.6% | 64.7% | 51.1% | 83.6% |
| Gradient Boosting | 80.1% | 66.4% | 51.2% | 84.5% |

**Winner:** Logistic Regression - đơn giản, interpretable, performance tốt.

---

## 💡 Business Recommendations

1. **Contract Upgrade Program** - Incentive cho Month-to-month → 1-2 year
2. **First-Year Retention** - Enhanced onboarding trong 12 tháng đầu
3. **Security Bundle** - Bundle Tech Support + Security cho Fiber users
4. **Auto-Payment Incentive** - Giảm giá cho auto-pay enrollment
5. **ML Scoring** - Deploy model để score high-risk customers monthly

---

## 📂 Deliverables

| File | Description |
|------|-------------|
| [📊 Presentation](./presentation/Customer_Churn_Analysis.pptx) | Business presentation (15 slides) |
| [📓 EDA Notebook](./notebooks/01_exploratory_data_analysis.ipynb) | Exploratory Data Analysis |
| [🤖 ML Notebook](./notebooks/02_predictive_modeling.ipynb) | Predictive Modeling |
| [📝 SQL Queries](./sql/churn_analysis_queries.sql) | 30+ analysis queries |
| [📋 Executive Summary](./reports/executive_summary.md) | Key findings summary |

---

## 📧 Contact

**Vũ Tiến Đức** - Data Analyst

| Platform | Contact |
|----------|---------|
| 📧 Email | vutienduc.31032003@gmail.com |
| 📱 Phone | 0367108536 |
| 💼 LinkedIn | [linkedin.com/in/vutienduc](https://linkedin.com/in/vutienduc) |
| 🐙 GitHub | [github.com/vutienduc](https://github.com/vutienduc) |

---

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

⭐ **If you found this project helpful, please give it a star!**
