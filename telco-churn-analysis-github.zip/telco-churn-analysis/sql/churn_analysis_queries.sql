-- ============================================
-- TELCO CUSTOMER CHURN ANALYSIS - SQL QUERIES
-- Author: Vũ Tiến Đức
-- Email: vutienduc.31032003@gmail.com
-- ============================================

-- ============================================
-- 1. DATA OVERVIEW & BASIC STATISTICS
-- ============================================

-- 1.1 Tổng quan dataset
SELECT 
    COUNT(*) AS total_customers,
    COUNT(DISTINCT customerID) AS unique_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned_customers,
    SUM(CASE WHEN Churn = 'No' THEN 1 ELSE 0 END) AS retained_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate_percent
FROM telco_customers;

-- 1.2 Phân bố theo giới tính
SELECT 
    gender,
    COUNT(*) AS customer_count,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate
FROM telco_customers
GROUP BY gender;

-- 1.3 Thống kê cơ bản về tenure và charges
SELECT 
    MIN(tenure) AS min_tenure,
    MAX(tenure) AS max_tenure,
    ROUND(AVG(tenure), 2) AS avg_tenure,
    MIN(MonthlyCharges) AS min_monthly,
    MAX(MonthlyCharges) AS max_monthly,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly,
    ROUND(SUM(TotalCharges), 2) AS total_revenue
FROM telco_customers;


-- ============================================
-- 2. CHURN ANALYSIS - DEEP DIVE
-- ============================================

-- 2.1 Churn rate theo loại hợp đồng
SELECT 
    Contract,
    COUNT(*) AS total_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly_charges,
    ROUND(AVG(tenure), 1) AS avg_tenure_months
FROM telco_customers
GROUP BY Contract
ORDER BY churn_rate DESC;

-- 2.2 Churn rate theo Internet Service
SELECT 
    InternetService,
    COUNT(*) AS total_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate,
    ROUND(SUM(MonthlyCharges), 2) AS total_monthly_revenue
FROM telco_customers
GROUP BY InternetService
ORDER BY churn_rate DESC;

-- 2.3 Churn rate theo Payment Method
SELECT 
    PaymentMethod,
    COUNT(*) AS total_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate
FROM telco_customers
GROUP BY PaymentMethod
ORDER BY churn_rate DESC;

-- 2.4 Churn theo tenure buckets
SELECT 
    CASE 
        WHEN tenure <= 6 THEN '0-6 months'
        WHEN tenure <= 12 THEN '7-12 months'
        WHEN tenure <= 24 THEN '13-24 months'
        WHEN tenure <= 48 THEN '25-48 months'
        ELSE '49+ months'
    END AS tenure_bucket,
    COUNT(*) AS total_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate
FROM telco_customers
GROUP BY 
    CASE 
        WHEN tenure <= 6 THEN '0-6 months'
        WHEN tenure <= 12 THEN '7-12 months'
        WHEN tenure <= 24 THEN '13-24 months'
        WHEN tenure <= 48 THEN '25-48 months'
        ELSE '49+ months'
    END
ORDER BY churn_rate DESC;

-- 2.5 Churn theo Senior Citizen status
SELECT 
    CASE WHEN SeniorCitizen = 1 THEN 'Senior (65+)' ELSE 'Non-Senior' END AS customer_type,
    COUNT(*) AS total_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly_charges
FROM telco_customers
GROUP BY SeniorCitizen;

-- 2.6 Impact của Tech Support
SELECT 
    TechSupport,
    COUNT(*) AS total_customers,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate
FROM telco_customers
WHERE InternetService != 'No'
GROUP BY TechSupport
ORDER BY churn_rate DESC;


-- ============================================
-- 3. CUSTOMER SEGMENTATION
-- ============================================

-- 3.1 High-Risk Customers (Fiber + Month-to-month + No Support)
SELECT 
    COUNT(*) AS high_risk_customers,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS actual_churn_rate,
    ROUND(SUM(MonthlyCharges), 2) AS monthly_revenue_at_risk,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly_charges
FROM telco_customers
WHERE InternetService = 'Fiber optic'
    AND Contract = 'Month-to-month'
    AND TechSupport = 'No';

-- 3.2 Customer Segments by Value & Risk
SELECT 
    CASE 
        WHEN MonthlyCharges >= 80 THEN 'High Value'
        WHEN MonthlyCharges >= 50 THEN 'Medium Value'
        ELSE 'Low Value'
    END AS value_segment,
    CASE 
        WHEN tenure <= 12 AND Contract = 'Month-to-month' THEN 'High Risk'
        WHEN tenure <= 24 OR Contract = 'Month-to-month' THEN 'Medium Risk'
        ELSE 'Low Risk'
    END AS risk_segment,
    COUNT(*) AS customer_count,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate,
    ROUND(SUM(MonthlyCharges), 2) AS total_monthly_revenue
FROM telco_customers
GROUP BY 
    CASE 
        WHEN MonthlyCharges >= 80 THEN 'High Value'
        WHEN MonthlyCharges >= 50 THEN 'Medium Value'
        ELSE 'Low Value'
    END,
    CASE 
        WHEN tenure <= 12 AND Contract = 'Month-to-month' THEN 'High Risk'
        WHEN tenure <= 24 OR Contract = 'Month-to-month' THEN 'Medium Risk'
        ELSE 'Low Risk'
    END
ORDER BY churn_rate DESC;

-- 3.3 Service adoption analysis
SELECT 
    CASE 
        WHEN OnlineSecurity = 'Yes' THEN 1 ELSE 0 
    END +
    CASE 
        WHEN OnlineBackup = 'Yes' THEN 1 ELSE 0 
    END +
    CASE 
        WHEN DeviceProtection = 'Yes' THEN 1 ELSE 0 
    END +
    CASE 
        WHEN TechSupport = 'Yes' THEN 1 ELSE 0 
    END AS services_count,
    COUNT(*) AS customer_count,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate
FROM telco_customers
WHERE InternetService != 'No'
GROUP BY 
    CASE 
        WHEN OnlineSecurity = 'Yes' THEN 1 ELSE 0 
    END +
    CASE 
        WHEN OnlineBackup = 'Yes' THEN 1 ELSE 0 
    END +
    CASE 
        WHEN DeviceProtection = 'Yes' THEN 1 ELSE 0 
    END +
    CASE 
        WHEN TechSupport = 'Yes' THEN 1 ELSE 0 
    END
ORDER BY services_count;


-- ============================================
-- 4. BUSINESS METRICS & KPIs
-- ============================================

-- 4.1 Revenue Impact Analysis
SELECT 
    Churn,
    COUNT(*) AS customer_count,
    ROUND(SUM(MonthlyCharges), 2) AS total_monthly_revenue,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly_charges,
    ROUND(SUM(TotalCharges), 2) AS total_historical_revenue,
    ROUND(AVG(TotalCharges), 2) AS avg_customer_value
FROM telco_customers
GROUP BY Churn;

-- 4.2 Monthly Revenue at Risk by Segment
SELECT 
    Contract,
    InternetService,
    COUNT(*) AS at_risk_customers,
    ROUND(SUM(MonthlyCharges), 2) AS monthly_revenue_at_risk,
    ROUND(AVG(tenure), 1) AS avg_tenure
FROM telco_customers
WHERE Churn = 'Yes'
GROUP BY Contract, InternetService
ORDER BY monthly_revenue_at_risk DESC;

-- 4.3 Customer Lifetime Value (CLV) Estimation
SELECT 
    Contract,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly_charges,
    ROUND(AVG(tenure), 1) AS avg_tenure_months,
    ROUND(AVG(MonthlyCharges) * AVG(tenure), 2) AS estimated_avg_clv,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate
FROM telco_customers
GROUP BY Contract
ORDER BY estimated_avg_clv DESC;

-- 4.4 Retention Opportunity - Saveable Revenue
WITH churn_analysis AS (
    SELECT 
        Contract,
        COUNT(*) AS churned_customers,
        SUM(MonthlyCharges) AS lost_monthly_revenue,
        AVG(tenure) AS avg_tenure_at_churn
    FROM telco_customers
    WHERE Churn = 'Yes'
    GROUP BY Contract
)
SELECT 
    Contract,
    churned_customers,
    ROUND(lost_monthly_revenue, 2) AS lost_monthly_revenue,
    ROUND(lost_monthly_revenue * 12, 2) AS annualized_loss,
    ROUND(lost_monthly_revenue * 12 * 0.25, 2) AS potential_savings_25pct_retention,
    ROUND(avg_tenure_at_churn, 1) AS avg_tenure_at_churn
FROM churn_analysis
ORDER BY lost_monthly_revenue DESC;


-- ============================================
-- 5. PREDICTIVE INSIGHTS QUERIES
-- ============================================

-- 5.1 Top factors correlated with churn
SELECT 
    'Month-to-month Contract' AS factor,
    ROUND(AVG(CASE WHEN Contract = 'Month-to-month' AND Churn = 'Yes' THEN 1.0 
                   WHEN Contract = 'Month-to-month' AND Churn = 'No' THEN 0 END) * 100, 2) AS churn_rate_with_factor,
    ROUND(AVG(CASE WHEN Contract != 'Month-to-month' AND Churn = 'Yes' THEN 1.0 
                   WHEN Contract != 'Month-to-month' AND Churn = 'No' THEN 0 END) * 100, 2) AS churn_rate_without_factor
FROM telco_customers

UNION ALL

SELECT 
    'Fiber Optic Internet' AS factor,
    ROUND(AVG(CASE WHEN InternetService = 'Fiber optic' AND Churn = 'Yes' THEN 1.0 
                   WHEN InternetService = 'Fiber optic' AND Churn = 'No' THEN 0 END) * 100, 2),
    ROUND(AVG(CASE WHEN InternetService != 'Fiber optic' AND Churn = 'Yes' THEN 1.0 
                   WHEN InternetService != 'Fiber optic' AND Churn = 'No' THEN 0 END) * 100, 2)
FROM telco_customers

UNION ALL

SELECT 
    'No Tech Support' AS factor,
    ROUND(AVG(CASE WHEN TechSupport = 'No' AND Churn = 'Yes' THEN 1.0 
                   WHEN TechSupport = 'No' AND Churn = 'No' THEN 0 END) * 100, 2),
    ROUND(AVG(CASE WHEN TechSupport != 'No' AND Churn = 'Yes' THEN 1.0 
                   WHEN TechSupport != 'No' AND Churn = 'No' THEN 0 END) * 100, 2)
FROM telco_customers

UNION ALL

SELECT 
    'Electronic Check Payment' AS factor,
    ROUND(AVG(CASE WHEN PaymentMethod = 'Electronic check' AND Churn = 'Yes' THEN 1.0 
                   WHEN PaymentMethod = 'Electronic check' AND Churn = 'No' THEN 0 END) * 100, 2),
    ROUND(AVG(CASE WHEN PaymentMethod != 'Electronic check' AND Churn = 'Yes' THEN 1.0 
                   WHEN PaymentMethod != 'Electronic check' AND Churn = 'No' THEN 0 END) * 100, 2)
FROM telco_customers;

-- 5.2 Customers most likely to churn (for proactive retention)
SELECT 
    customerID,
    gender,
    SeniorCitizen,
    tenure,
    Contract,
    InternetService,
    TechSupport,
    MonthlyCharges,
    PaymentMethod,
    -- Risk Score calculation
    (CASE WHEN Contract = 'Month-to-month' THEN 30 ELSE 0 END +
     CASE WHEN InternetService = 'Fiber optic' THEN 20 ELSE 0 END +
     CASE WHEN TechSupport = 'No' AND InternetService != 'No' THEN 15 ELSE 0 END +
     CASE WHEN PaymentMethod = 'Electronic check' THEN 15 ELSE 0 END +
     CASE WHEN tenure <= 6 THEN 20 WHEN tenure <= 12 THEN 10 ELSE 0 END) AS churn_risk_score
FROM telco_customers
WHERE Churn = 'No'
ORDER BY churn_risk_score DESC
LIMIT 100;


-- ============================================
-- 6. EXECUTIVE SUMMARY QUERIES
-- ============================================

-- 6.1 Dashboard Summary Metrics
SELECT 
    'Total Customers' AS metric, CAST(COUNT(*) AS VARCHAR) AS value FROM telco_customers
UNION ALL
SELECT 'Churn Rate', CONCAT(ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 1), '%') FROM telco_customers
UNION ALL
SELECT 'Monthly Revenue', CONCAT('$', ROUND(SUM(MonthlyCharges), 0)) FROM telco_customers
UNION ALL
SELECT 'Revenue at Risk', CONCAT('$', ROUND(SUM(CASE WHEN Churn = 'Yes' THEN MonthlyCharges ELSE 0 END), 0)) FROM telco_customers
UNION ALL
SELECT 'Avg Customer Tenure', CONCAT(ROUND(AVG(tenure), 1), ' months') FROM telco_customers
UNION ALL
SELECT 'Avg Monthly Charges', CONCAT('$', ROUND(AVG(MonthlyCharges), 2)) FROM telco_customers;

-- 6.2 Month-over-Month Comparison (simulated by tenure cohorts)
SELECT 
    CASE 
        WHEN tenure % 12 = 0 THEN 12
        ELSE tenure % 12 
    END AS month_cohort,
    COUNT(*) AS customers_in_cohort,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS churned_in_cohort,
    ROUND(AVG(CASE WHEN Churn = 'Yes' THEN 1.0 ELSE 0 END) * 100, 2) AS churn_rate
FROM telco_customers
GROUP BY 
    CASE 
        WHEN tenure % 12 = 0 THEN 12
        ELSE tenure % 12 
    END
ORDER BY month_cohort;
